#!/usr/bin/env python3
"""Offline policy improvement demonstration: deterministic, Python stdlib only.

Synthetic independent one-step contextual bandit observations (one per user).
No sequential return, no online safety guarantee, no external data.
"""
from __future__ import annotations
import argparse
import json
import math
import random
from pathlib import Path

P_CONTEXT_1 = 0.25
REWARD_TRUE = ((0.57, 0.19), (0.34, 0.69))  # context x action
REWARD_MODEL = ((0.56, 0.74), (0.35, 0.68))  # fixed and intentionally misspecified
SCENARIOS = {
    'balanced': {'mu': (0.45, 0.55), 'recorded': (0.45, 0.55), 'label': 'Good overlap'},
    'weak': {'mu': (0.015, 0.08), 'recorded': (0.015, 0.08), 'label': 'Rare exploration'},
    'mislogged': {'mu': (0.015, 0.08), 'recorded': (0.45, 0.55), 'label': 'Wrong propensities'},
    'zero': {'mu': (0.0, 0.08), 'recorded': (0.0, 0.08), 'label': 'No support'},
}
POLICIES = ('baseline', 'targeted', 'popular', 'blend')
SIZES = (300, 900, 3000)
SEEDS = 100

def action_prob(policy: str, x: int, mu: tuple[float, float]) -> float:
    if policy == 'baseline': return mu[x]
    if policy == 'targeted': return float(x == 1)
    if policy == 'popular': return 1.0
    if policy == 'blend': return 0.6 * mu[x] + 0.4 * float(x == 1)
    raise ValueError(policy)

def true_value(policy: str, mu: tuple[float, float]) -> float:
    return sum((1 - P_CONTEXT_1 if x == 0 else P_CONTEXT_1) *
               ((1 - action_prob(policy, x, mu)) * REWARD_TRUE[x][0] +
                action_prob(policy, x, mu) * REWARD_TRUE[x][1]) for x in (0, 1))

def sample_run(scenario: str, n: int, seed: int) -> dict:
    meta = SCENARIOS[scenario]
    mu, mu_hat = meta['mu'], meta['recorded']
    rng = random.Random(seed + 1000003 * list(SCENARIOS).index(scenario) + n * 17)
    logs = []
    for _ in range(n):
        x = int(rng.random() < P_CONTEXT_1)
        a = int(rng.random() < mu[x])
        r = int(rng.random() < REWARD_TRUE[x][a])
        logs.append((x, a, r))
    baseline_sample = sum(r for _, _, r in logs) / n
    true = {p: true_value(p, mu) for p in POLICIES}
    estimates = {}
    for policy in POLICIES:
        if policy == 'baseline':
            estimates[policy] = {'dm': None, 'ips': baseline_sample, 'dr': baseline_sample,
                                 'se': 0., 'ess': n, 'supported': True}
            continue
        # Positivity: if a policy needs an action with zero true logging mass,
        # IPS/DR are not data-identified. Existence of q_hat doesn't fix this.
        supported = all(not (pa > 1e-12 and ma < 1e-12) and
                        not (pa < 1-1e-12 and ma > 1-1e-12)
                        for x in (0, 1)
                        for pa, ma in [(action_prob(policy, x, mu), mu[x])])
        dm_sum = ips_sum = dr_sum = w_sum = w2_sum = 0.
        differences = []
        for x, a, r in logs:
            pi1 = action_prob(policy, x, mu)
            q_pi = (1 - pi1) * REWARD_MODEL[x][0] + pi1 * REWARD_MODEL[x][1]
            dm_sum += q_pi
            recorded_pa = mu_hat[x] if a else (1 - mu_hat[x])
            target_pa = pi1 if a else (1 - pi1)
            w = target_pa / recorded_pa if recorded_pa > 0 else 0.
            ips_sum += w * r
            dr = q_pi + w * (r - REWARD_MODEL[x][a])
            dr_sum += dr
            differences.append(dr - r)
            w_sum += w
            w2_sum += w * w
        mean_diff = sum(differences) / n
        variance_diff = (sum((v - mean_diff) ** 2 for v in differences) / (n - 1)) if n > 1 else 0
        estimates[policy] = {
            'dm': round(dm_sum / n, 7),
            'ips': round(ips_sum / n, 7) if supported else None,
            'dr': round(dr_sum / n, 7) if supported else None,
            'se': round(math.sqrt(variance_diff / n), 7) if supported else None,
            'ess': round(w_sum * w_sum / w2_sum, 2) if w2_sum else 0,
            'supported': supported,
        }
    return {
        'seed': seed, 'baseline_sample': round(baseline_sample, 7),
        'true': {k: round(v, 7) for k, v in true.items()},
        'estimates': estimates
    }

def choose(run: dict, method: str, z: float = 2.33, min_ess: float = 30) -> str:
    candidates = ['baseline', 'targeted', 'popular', 'blend']
    base = run['baseline_sample']
    if method == 'dm':
        # Only candidate estimates; baseline retains observed mean.
        return max(candidates, key=lambda p: base if p == 'baseline' else run['estimates'][p]['dm'])
    if method == 'dr':
        return max(candidates, key=lambda p: run['estimates'][p]['dr'] if run['estimates'][p]['supported'] else -1e9)
    if method == 'guard':
        eligible = [p for p in candidates if p != 'baseline' and run['estimates'][p]['supported']
                    and run['estimates'][p]['ess'] >= min_ess
                    and run['estimates'][p]['dr'] - base - z * run['estimates'][p]['se'] > 0]
        return max(eligible, key=lambda p: run['estimates'][p]['dr'] - base - z * run['estimates'][p]['se']) if eligible else 'baseline'
    raise ValueError(method)

def dataset(seeds: int = SEEDS) -> dict:
    scenarios = {}
    for scenario in SCENARIOS:
        scenarios[scenario] = {}
        for n in SIZES:
            scenarios[scenario][str(n)] = [sample_run(scenario, n, seed) for seed in range(seeds)]
    return {'schema_version': 1, 'seeds': seeds, 'sizes': list(SIZES),
            'scenarios': scenarios,
            'meta': {'p_context_1': P_CONTEXT_1,
                     'true_rewards': REWARD_TRUE, 'reward_model': REWARD_MODEL,
                     'scenarios': SCENARIOS, 'policies': list(POLICIES)}}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scenario', choices=SCENARIOS)
    parser.add_argument('--n', type=int, default=900)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--export-site', action='store_true', help='Generate bundled browser data and CSV summary')
    args = parser.parse_args()
    if args.export_site:
        data = dataset()
        site = Path(__file__).resolve().parent.parent / 'public/research/offline-policy-improvement'
        site.mkdir(parents=True, exist_ok=True)
        (site / 'data.js').write_text('window.LAB_DATA = ' + json.dumps(data, ensure_ascii=False, separators=(',', ':')) + ';\n', encoding='utf-8')
        # One row per replicate, policy and estimator selection for aggregate audit.
        import csv
        out = Path(__file__).resolve().parent / 'selection_audit.csv'
        with out.open('w', newline='', encoding='utf-8') as fp:
            w = csv.writer(fp)
            w.writerow(['scenario','n','seed','method','selected','true_selected','true_baseline','harm','improved'])
            for scenario, ns in data['scenarios'].items():
                for n, runs in ns.items():
                    for run in runs:
                        for method in ('dm', 'dr', 'guard'):
                            pick = choose(run, method)
                            delta = run['true'][pick] - run['true']['baseline']
                            w.writerow([scenario,n,run['seed'],method,pick,run['true'][pick],run['true']['baseline'],int(delta < -1e-10),int(delta > 1e-10)])
        print(f'Wrote {site / "data.js"} and {out}')
        return
    if not args.scenario:
        parser.error('Use --scenario ... or --export-site')
    print(json.dumps(sample_run(args.scenario, args.n, args.seed), indent=2))

if __name__ == '__main__': main()
