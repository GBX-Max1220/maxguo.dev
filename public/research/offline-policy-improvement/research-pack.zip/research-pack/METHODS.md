# When Offline Evaluation Misleads — Methods and limits

**Type:** reproducible educational synthetic experiment, not a new algorithm or an empirical study of real users. **Revision:** 2026-10-28. **Units:** mean click reward per independent one-step user interaction; 0–1 Bernoulli outcome.

## The estimand

For a contextual bandit with independently sampled context `X ∈ {0,1}`, reward `R ∈ {0,1}`, and chosen action `A ∈ {0,1}`, compare the value `V(pi)=E_X Σ_a pi(a|X) E[R|X,a]` of fixed candidate policies. `P(X=1)=0.25`; reward success probabilities are:

| Context | Action 0 | Action 1 |
|---|---:|---:|
| X=0 | 0.57 | 0.19 |
| X=1 | 0.34 | 0.69 |

There is one interaction per independent user; therefore this is **not** a trajectory, MDP, policy-induced user preference change, long-term retention study, or safe online trial. The simulator can compute true values analytically; no estimator or selector has access to truth during a decision.

## Historical logging, deliberate violations

| Scenario | Actual P(A=1|X=0), P(A=1|X=1) | Logged / estimated probabilities | Targeted failure |
|---|---|---|---|
| `balanced` | (.45, .55) | (.45, .55) | Healthy support, misspecified reward model |
| `weak` | (.015, .08) | (.015, .08) | Rare actions and high variance |
| `mislogged` | (.015, .08) | (.45, .55) | Wrong propensities + misspecified reward model |
| `zero` | (0, .08) | (0, .08) | Lack of support for action 1 at context 0 |

The deliberately *fixed* reward-model predictions (not fitted on the evaluation sample) are `q_hat(X=0,A=0)=0.56`, `q_hat(0,1)=0.74`, `q_hat(1,0)=0.35`, `q_hat(1,1)=0.68`. The `q_hat(0,1)=0.74` prediction is intentionally extremely wrong (true value 0.19). This creates a **stress test**, not a naturally occurring trained-model failure rate.

## Candidate policies

- `baseline`: actual context-dependent historical stochastic policy `mu` (the only policy deployed to generate the synthetic log).
- `targeted`: deterministic action 0 for context 0, action 1 for context 1.
- `popular`: always action 1, a deliberately bad policy in a common context.
- `blend`: once per user, choose the baseline policy with probability 0.6 and targeted policy with probability 0.4; its action probabilities are 0.6*mu + 0.4*pi_targeted.

All policies are fixed **before** each dataset is sampled. Each experiment consists of 100 fixed deterministic Python RNG seeds (0–99) at sample sizes N=300, 900, and 3,000. Four scenarios × three sample sizes × 100 seeds = 1,200 log datasets. Python uses `random.Random` with explicit seeds, not a GPU or external API.

## Evaluation

- `DM(pi) = mean_i Σ_a pi(a|x_i) q_hat(x_i,a)`. Deliberately biased under reward misspecification.
- `IPS(pi) = mean_i [pi(a_i|x_i) / mu_hat(a_i|x_i)] r_i`.
- `DR(pi) = mean_i [Σ_a pi(a|x_i) q_hat(x_i,a) + pi(a_i|x_i)/mu_hat(a_i|x_i)·(r_i−q_hat(x_i,a_i))]`.
- The `baseline` reference estimate is the unweighted observed log mean `mean_i r_i`, which is unbiased for its actual logging policy when the sampling distribution and logging remain fixed. The output table intentionally uses this as baseline under all three columns rather than treating it as a fitted model.
- `ESS(pi)=(Σ_i w_i)²/(Σ_i w_i²)`, using *observed importance weights* and defining 0 when denominator is zero. **ESS measures concentration of weights, not action-coverage validity.**
- **Support detection:** if any action with positive target-policy probability has exactly zero actual logging probability in a context of positive probability, mark IPS and DR as `unidentified` (`null` in the result). DM is displayed because it can extrapolate, but that extrapolation is not identified by logs. For the synthetic stress test only, the evaluator knows the logging support set even in `mislogged`, but uses wrong recorded probabilities there.
- A separate, intentionally imperfect conservative gate chooses the candidate with largest positive `LCB = [mean_i(DR_pi,i − R_i)] − z·SE(DR_pi,i−R_i)` subject to observed ESS ≥ threshold and structural support. Otherwise it retains baseline. `SE` is an iid sample-standard-deviation plug-in over paired per-user differences divided by sqrt(N). Default `z=2.33`, ESS minimum=30.

## What 'conservative' does *not* mean here

The gate is **not** a formal high-confidence safe policy improvement algorithm. A normal lower bound may be unreliable for heavy-tailed rare importance weights; selection and evaluation use the *same dataset*; multiple candidate comparisons have not been adjusted; the propensity and reward models may both be wrong; and no finite-sample coverage guarantee or holdout evaluation is provided. The term describes an exploratory screening heuristic, not deployment authorization.

The `mislogged` scenario tests a severe specification violation. As sample size rises, incorrect propensity weighting can converge confidently to an incorrect value. When the gate selects a harmful policy, it is an *oracle-labeled synthetic harmful selection*, not an observed real-world harm event.

The provided `selection_audit.csv` includes per-seed `selected`, `true_selected`, `true_baseline`, `harm`, and `improved` under **default** gate parameters. The site updates its aggregated rates in JavaScript as z and ESS thresholds change; the CSV does not change with controls. True rewards never enter `choose()`.

## Replication

Run from the `research-pack` folder:

```sh
python reproduce.py --scenario weak --n 900 --seed 0
python -m unittest test_reproduce.py
python reproduce.py --export-site
```

The last command regenerates `data.js` and `selection_audit.csv` in the original extracted project's site directory (if you preserve the project layout). `data.js` is a static precomputed result bundle; the front end performs no network requests and contains no synthetic outcome generation of its own. Use one pinned Python version if byte-identical regenerated files are needed; each environment still produces deterministic results for the given version.

## Related scholarship

- Dudík, M., Langford, J., & Li, L. (2011). Doubly Robust Policy Evaluation and Learning. https://arxiv.org/abs/1103.4601
- Thomas, P. S., Theocharous, G., & Ghavamzadeh, M. (2015). High Confidence Policy Improvement. https://proceedings.mlr.press/v37/thomas15.html
- Laroche, R., Trichelair, P., & Tachet des Combes, R. (2019). Safe Policy Improvement with Baseline Bootstrapping. https://proceedings.mlr.press/v97/laroche19a.html

These papers provide methodological context. This educational heuristic is **not** their implementation and does not inherit their guarantees.
