"""Deterministic and identification checks; Python stdlib only."""
import math
import unittest
from reproduce import (SCENARIOS, REWARD_TRUE, REWARD_MODEL, P_CONTEXT_1,
                       POLICIES, action_prob, true_value, sample_run, choose)

class PolicyLabTests(unittest.TestCase):
    def test_true_value_matches_manual(self):
        mu=SCENARIOS['balanced']['mu']
        expected=(1-P_CONTEXT_1)*REWARD_TRUE[0][0]+P_CONTEXT_1*REWARD_TRUE[1][1]
        self.assertAlmostEqual(true_value('targeted',mu),expected)

    def test_blend_is_convex_combination_of_full_policies(self):
        for scenario in SCENARIOS:
            mu=SCENARIOS[scenario]['mu']
            b=true_value('baseline',mu)
            a=true_value('targeted',mu)
            self.assertAlmostEqual(true_value('blend',mu),0.6*b+0.4*a)

    def test_rng_replay_is_exact(self):
        self.assertEqual(sample_run('weak',900,12),sample_run('weak',900,12))
        self.assertNotEqual(sample_run('weak',900,12),sample_run('weak',900,13))

    def test_zero_support_correctly_flagged(self):
        r=sample_run('zero',900,4)
        self.assertFalse(r['estimates']['popular']['supported'])
        self.assertIsNone(r['estimates']['popular']['dr'])
        self.assertIsNone(r['estimates']['popular']['ips'])
        self.assertTrue(r['estimates']['targeted']['supported'])
        self.assertTrue(r['estimates']['blend']['supported'])
        self.assertNotEqual(choose(r,'guard'), 'popular')

    def test_true_coverage_in_nonzero_scenarios(self):
        for scenario in ['balanced','weak','mislogged']:
            r=sample_run(scenario,300,10)
            for p in POLICIES: self.assertTrue(r['estimates'][p]['supported'])

    def test_dr_population_expectation_double_robust_for_correct_mu(self):
        # Average over exact action and reward conditional expectations, not noisy sample.
        for scenario in ['balanced','weak']:
            mu=SCENARIOS[scenario]['mu']
            for policy in ('targeted','popular','blend'):
                expected=0.
                for x in (0,1):
                    px=P_CONTEXT_1 if x else (1-P_CONTEXT_1)
                    pi1=action_prob(policy,x,mu)
                    qpi=(1-pi1)*REWARD_MODEL[x][0]+pi1*REWARD_MODEL[x][1]
                    corr=0.
                    for a in (0,1):
                        pa=mu[x] if a else 1-mu[x]
                        target=pi1 if a else 1-pi1
                        corr+=pa*(target/pa)*(REWARD_TRUE[x][a]-REWARD_MODEL[x][a])
                    expected+=px*(qpi+corr)
                self.assertAlmostEqual(expected,true_value(policy,mu),places=12)

    def test_mislogged_dr_population_bias(self):
        mu=SCENARIOS['mislogged']['mu']
        recorded=SCENARIOS['mislogged']['recorded']
        policy='popular'
        expected=0.
        for x in (0,1):
            px=P_CONTEXT_1 if x else 1-P_CONTEXT_1
            pi1=action_prob(policy,x,mu)
            qpi=REWARD_MODEL[x][1]
            corr=0.
            for a in (0,1):
                pa=mu[x] if a else 1-mu[x]
                denom=recorded[x] if a else 1-recorded[x]
                target=pi1 if a else 1-pi1
                corr+=pa*target/denom*(REWARD_TRUE[x][a]-REWARD_MODEL[x][a])
            expected+=px*(qpi+corr)
        self.assertGreater(expected,true_value(policy,mu)+0.25)

    def test_conservative_gating_can_fail_with_invalid_propensities(self):
        runs=[sample_run('mislogged',3000,s) for s in range(20)]
        self.assertTrue(any(r['true'][choose(r,'guard')]<r['true']['baseline'] for r in runs))

    def test_all_probabilities_and_se_are_valid(self):
        for scenario in SCENARIOS:
            r=sample_run(scenario,300,0)
            for p in POLICIES:
                self.assertGreaterEqual(r['true'][p],0.)
                self.assertLessEqual(r['true'][p],1.)
                e=r['estimates'][p]
                self.assertGreaterEqual(e['ess'],0.)
                if e['supported']:
                    self.assertTrue(math.isfinite(e['dr']))
                    self.assertTrue(math.isfinite(e['ips']))
                    self.assertGreaterEqual(e['se'],0.)

if __name__=='__main__': unittest.main()
