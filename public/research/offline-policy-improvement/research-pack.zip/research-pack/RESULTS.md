# Frozen example results, 100 seeds × scenario × sample size

These figures are **synthetic known-truth counts** at the default gate `z=2.33`, `min_ESS=30`, with the fixed deliberately misspecified reward model. They are not confidence intervals or real-user outcome rates.

| Scenario | Users | DM harmful /100 | DR harmful /100 | Guarded harmful /100 | Guarded improved /100 |
|---|---:|---:|---:|---:|---:|
| Balanced exposure | 300 | 100 | 0 | 0 | 100 |
| Balanced exposure | 900 | 100 | 0 | 0 | 100 |
| Balanced exposure | 3000 | 100 | 0 | 0 | 100 |
| Rare exploration | 300 | 100 | 19 | 0 | 35 |
| Rare exploration | 900 | 100 | 2 | 0 | 72 |
| Rare exploration | 3000 | 100 | 0 | 0 | 100 |
| Wrong propensities | 300 | 100 | 97 | 0 | 89 |
| Wrong propensities | 900 | 100 | 100 | 29 | 71 |
| Wrong propensities | 3000 | 100 | 100 | 100 | 0 |
| Zero support | 300 | 100 | 0 | 0 | 39 |
| Zero support | 900 | 100 | 0 | 0 | 76 |
| Zero support | 3000 | 100 | 0 | 0 | 100 |

**Interpretation:** at a larger sample size under an invalid logging-probability model, estimated standard errors shrink around a biased limit. Therefore a seemingly conservative selection heuristic can select harmful policies more often. This does not contradict doubly robust theory; both reward predictions and logged propensity estimates are intentionally wrong. The misspecified reward model strongly favors an unsuitable always-action-1 policy, explaining DM's pathological performance. These scenarios are illustrative stress tests by design, not representative prevalence estimates.

Details: `METHODS.md`; per-run audit: `selection_audit.csv`; exact code: `reproduce.py`.
