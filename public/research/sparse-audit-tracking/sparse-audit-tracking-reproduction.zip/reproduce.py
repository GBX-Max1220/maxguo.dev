"""Reproduce the sparse-audit diagnostic. Run with Python 3 and NumPy."""
from math import comb, log
import numpy as np

SEEDS, WINDOWS, LABELS = 2400, 30, 5
THRESHOLD = 4.826425232904121  # Frozen threshold from the original simulation.
GRID = 100_000
METHODS = ("frozen", "EMA .25", "EMA .10", "rolling", "shrinkage", "alarm + EMA")


def binomial(n, p):
    return np.array([comb(n, k) * p**k * (1 - p)**(n-k) for k in range(n + 1)])


def audit_panel():
    rng = np.random.default_rng(20261124)
    change = rng.integers(8, 17, SEEDS)
    draws = rng.random((SEEDS, WINDOWS, LABELS))
    return change, draws


def simulate(prior, delta, change, draws):
    truth = .20 + delta * (np.arange(WINDOWS) >= change[:, None])
    totals = (draws < truth[:, :, None]).sum(axis=2)
    estimates = np.empty((SEEDS, WINDOWS, len(METHODS)))
    pred = np.full((SEEDS, len(METHODS)), prior)
    cusum = np.zeros(SEEDS)
    alarmed = np.zeros(SEEDS, dtype=bool)
    for t, y in enumerate(totals.T):
        local = y / LABELS
        rolling = totals[:, max(0, t-3):t+1]
        count = rolling.shape[1] * LABELS
        pred[:, 1] += .25 * (local-pred[:, 1])
        pred[:, 2] += .10 * (local-pred[:, 2])
        pred[:, 3] = rolling.sum(axis=1) / count
        pred[:, 4] = (rolling.sum(axis=1) + 20*prior) / (count+20)
        cusum = np.maximum(0, cusum + y*log(.35/.20) + (LABELS-y)*log(.65/.80))
        alarmed |= cusum > THRESHOLD
        pred[alarmed, 5] += .25 * (local[alarmed]-pred[alarmed, 5])
        estimates[:, t] = pred
    return estimates - truth[:, :, None]


def scored(t, change, delta):
    return delta == 0 or change <= t < change + 10


def analytic(prior, delta, grid):
    # Each rolling estimate has a finite exact distribution. For the EMA,
    # propagate probability mass on a grid and compare two resolutions.
    ema_dest = {
        alpha: [np.rint(((1-alpha)*np.arange(grid + 1) + alpha*k*grid/LABELS)).astype(int)
                for k in range(LABELS+1)]
        for alpha in (.25, .10)
    }
    sums = np.zeros(5)
    count = 0
    for change in range(8, 17):
        masses = {alpha: np.zeros(grid+1) for alpha in ema_dest}
        for mass in masses.values():
            mass[round(prior*grid)] = 1.
        ps = []
        for t in range(WINDOWS):
            p = .20 + delta * (t >= change)
            ps.append(p)
            probs = binomial(LABELS, p)
            for alpha, destinations in ema_dest.items():
                masses[alpha] = sum(
                    prob * np.bincount(dest, weights=masses[alpha], minlength=grid+1)
                    for prob, dest in zip(probs, destinations)
                )
            if not scored(t, change, delta):
                continue
            error = np.abs(np.arange(grid+1)/grid - p)
            rolling_probs = np.array([1.])
            for pp in ps[-4:]:
                rolling_probs = np.convolve(rolling_probs, binomial(LABELS, pp))
            cases = np.arange(len(rolling_probs))
            n = len(cases)-1
            sums += [
                abs(prior-p),
                np.sum(masses[.25]*error), np.sum(masses[.10]*error),
                np.sum(rolling_probs*np.abs(cases/n-p)),
                np.sum(rolling_probs*np.abs((cases+20*prior)/(n+20)-p)),
            ]
            count += 1
    return sums/count


def main():
    change, draws = audit_panel()
    print("prior,shift_pp,method,mae_pp,mc_se_pp,analytic_mae_pp,bias_rms_pp,sd_rms_pp")
    for prior in (.20, .24):
        for delta in (0, .05, .15):
            residual = simulate(prior, delta, change, draws)
            if delta:
                residual = residual[np.arange(SEEDS)[:, None], change[:, None]+np.arange(10)]
            base = analytic(prior, delta, GRID)
            fine = analytic(prior, delta, 2*GRID)
            assert np.max(np.abs(base-fine))*100 < .01
            sample_mae = np.abs(residual).mean(axis=1)
            mae = sample_mae.mean(axis=0)
            se = sample_mae.std(axis=0, ddof=1)/np.sqrt(SEEDS)
            assert np.all(np.abs(mae[:5]-fine) <= 4*se[:5]+.0001)
            bias = np.sqrt(np.mean(residual.mean(axis=0)**2, axis=0))
            spread = np.sqrt(np.mean(residual.var(axis=0), axis=0))
            assert np.allclose(np.mean(residual**2, axis=(0,1)), bias**2+spread**2)
            for i, method in enumerate(METHODS):
                exact = f"{100*fine[i]:.4f}" if i < len(fine) else ""
                print(f"{prior},{100*delta:.0f},{method},{100*mae[i]:.4f},{100*se[i]:.4f},{exact},"
                      f"{100*bias[i]:.4f},{100*spread[i]:.4f}")


if __name__ == "__main__":
    main()
