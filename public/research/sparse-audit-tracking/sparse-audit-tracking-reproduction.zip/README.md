# Sparse audit labels and online prediction after a step change

This note closes a synthetic diagnostic. In the scored region, routine labels
are absent. The learners track one Bernoulli mean from five independent audit
labels per window. No policy updates the audit allocation, and no learner uses
a biased routine stream alongside the audits.

## Run

Install NumPy, then run:

```sh
python reproduce.py > results.csv
```

The script uses a fixed NumPy seed and 2,400 paired runs. Its random stream is
independent of the original JavaScript run. It preserves the hidden-region DGP,
update rules, and previously calibrated CUSUM threshold. The threshold was
calibrated for monitoring two regions in the original simulation. This
reproduction uses only the hidden stream.

## Design

Each run has 30 windows. The pre-change probability is 0.20. The shift is
0, +0.05, or +0.15, with the change time uniform over zero-based windows 8–16.
The two initial predictions are 0.20 and 0.24. Each rule observes the same
labels through the current window. Prediction error is measured after that
window's update. Drift metrics cover the first ten post-change windows and
stationary metrics cover all 30.

The six comparisons are a fixed initial predictor, EMA with gains 0.25
and 0.10, a four-window rolling mean, the same rolling mean with a prior
worth 20 observations, and an upward CUSUM followed by a gain-0.25 EMA.
The CUSUM is configured for 0.20 versus 0.35 and uses the true pre-change
rate also when the predictor starts at 0.24.

## Reconciliation

* Frozen predictions and rolling windows have finite exact distributions.
  The rolling count distribution is obtained by convolving the per-window
  binomial counts.
* EMA MAE is computed by propagating the estimate's distribution on a grid.
  Doubling the grid resolution must change MAE by less than 0.01 percentage
  points. The script checks the simulated MAE against the computed MAE for
  all five non-CUSUM rules, to within four Monte Carlo standard errors plus a
  numerical tolerance. At stationarity the EMA variance is
  alpha/(2-alpha) times the variance of one window's mean.
* The full rolling window uses 20 new labels and a prior worth 20 labels.
  The post-change bias is -7.5 pp when truth is 0.35 and the prior is 0.20.
  It is -5.5 pp with a 0.24 prior.
* The expected CUSUM increment per label at p=0.25 is -0.015826 nats.
  At p=0.35 it is +0.060900 nats. This explains the direction of the
  small-shift sensitivity. The CUSUM MAE column comes from simulation;
  there is no analytic first-passage calculation in this note.

The CSV reports MAE, Monte Carlo standard error across independent paired
replicates, root-mean-squared bias across scored windows, and the square root
of the mean across-window variance. The last two square and add to MSE,
which the script checks. MAE has no such additive decomposition.

## Decision

The evidence supports a finite-sample smoothing and lag trade-off in this
audit-only simulation. The observed trade-off is explained by the tracking
model. The current results do not establish a contribution about learning
from selectively observed routine feedback or about reallocating audits.
